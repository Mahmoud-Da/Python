print("Ecommerce initialized")
